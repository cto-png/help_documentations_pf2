=== Prodamus Plugin ===


Contributors: Prodamus
Tags: woocommerce, cachback
Requires at least: 6.0
Tested up to: 6.7.1
Stable tag: 2.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==


Prodamus is a unified system of accounting and order processing for LLC, sole proprietors and the self-employed, as well as a set of other tools for conducting business on the Internet.
With the help of the application, you will be able to accept payment for your services or goods in a couple of clicks with a minimum initial Prodamus commission using any available payment methods: bank cards of the Russian Federation, bank cards of foreign banks, payment systems, SBP, payment by invoice.
Before using the module, you must register
with the service https://prodamus.ru . In the personal account of the service, you will have access to: API key, partner ID. These parameters must be specified in the module settings.


The 'woocommerce-prodamus` plugin uses https://prodamus.ru a service for your work.
The following information is transmitted to prodamus.ru maintenance:
1. Order information.


By installing this plugin, you agree to the following documents:
Privacy Policy - https://prodamus.ru/privacy
Description of processes - https://prodamus.ru/opisanie-processov
Documentation of functional characteristics - https://prodamus.ru/dokumentaciya
Tariffs for the provision of software https://prodamus.ru/tarif201022
Offer - https://prodamus.ru/oferta
Application for accession - https://prodamus.ru/zayavlenie
Partner program offer - https://prodamus.ru/oferta/partners


== Installation ==


1. Download `woocommerce-prodamus.zip `to directory `/wp-content/plugins/`
2. Activate the plugin via the Plugins menu in WordPress
3. Configure the plugin by adding a secret key and the URL of your payment page.
3. Done.


== Screenshots ==


== Changelog ==


== Frequently Asked Questions ==


How do I connect to Prodamus?
Answer: You need to go to https://prodamus.ru and fill out an application for connection, after that the specialists of the Prodamus company will contact you. 


Where can I find detailed installation instructions?
Answer: You can find more detailed instructions on our website in the “help” section at https://help.prodamus.ru/ 


== Upgrade Notice ==


You can track news about updates in our telegram channel https://t.me/prodamus_ru
<?php 
  /**
  * Plugin Name: Commerce Payment Gateway "Продамус"
  * Plugin URI: https://payform.ru/
  * Description: Проведение платежей через "Продамус"
  * Version: 1.2.0
  * Author: Prodamus Ltd
  * Author URI: https://prodamus.ru/
  * Requires at least: 5.8
  * Requires PHP: 7.2
  * Text Domain: wc-prodamus
  */
if (!defined("ABSPATH")) {
  exit();
}

add_action("plugins_loaded", "woocommerce_gateway_prodamus_init");
function woocommerce_gateway_prodamus_init()
{

  if (!class_exists("WC_Payment_Gateway")) {
    return;
  } 

  add_filter('woocommerce_payment_gateways', 'woocommerce_gateway_prodamus_add' );
  add_action('before_woocommerce_init', 'declare_prodamus_block_compatibility');
  add_action( 'woocommerce_blocks_loaded', 'oawoo_register_order_approval_payment_method_type' );

  function woocommerce_gateway_prodamus_add($methods)
  {
    $methods[] = "WC_Gateway_Prodamus"; 
    return $methods;
  }
  
  function declare_prodamus_block_compatibility() {
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
      \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);
    }
  }
  
  function oawoo_register_order_approval_payment_method_type() {

    if (!class_exists( 'Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType')){
      return;
    }   
    
    require_once  plugin_dir_path(__FILE__) . 'wc_prodamus_blocks.php' ;

    add_action(
    'woocommerce_blocks_payment_method_type_registration',
      function( Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry $payment_method_registry ) {
        $payment_method_registry->register( new wc_prodamus_blocks  );
      }
    );
  }


  class WC_Gateway_Prodamus extends WC_Payment_Gateway
  {
    public $id;
    public $has_fields;
    public $method_title;
    public $method_description;
    public $title;
    public $demo_mode;
    public $description;
    public $payment_site_name;
    public $secret_key;
    public $order_status;
    public $urlReturn;
    public $urlSuccess;
    public $order_status_ready_pay;
    public $availableMethods;
    public $currency;
    public $enabled;
    public $prodamus_payment_methods = [
      'prodamus_checkbox' => 'AC', 
      '_prodamus_checkbox_ACUSDXP' => 'ACUSDXP', 
      '_prodamus_checkbox_ACkz' => 'ACkz', 
      '_prodamus_checkbox_ACkztjp' => 'ACkztjp', 
      '_prodamus_checkbox_ACusd' => 'ACusd', 
      '_prodamus_checkbox_ACeur' => 'ACeur', 
      '_prodamus_checkbox_SBP' => 'SBP', 
      '_prodamus_checkbox_ACBYNGTL' => 'ACBYNGTL', 
      '_prodamus_checkbox_PC' => 'PC', 
      '_prodamus_checkbox_QW' => 'QW', 
      '_prodamus_checkbox_GP' => 'GP', 
      '_prodamus_checkbox_sbol' => 'sbol', 
      '_prodamus_checkbox_invoice' => 'invoice', 
      '_prodamus_checkbox_ACeuruk' => 'ACeuruk', 
      '_prodamus_checkbox_ACf' => 'ACf', 
      '_prodamus_checkbox_installment' => 'installment', 
      '_prodamus_checkbox_installment_5_21' => 'installment_5_21', 
      '_prodamus_checkbox_installment_6_28' => 'installment_5_21', 
      '_prodamus_checkbox_installment_10_28' => 'installment_10_28', 
      '_prodamus_checkbox_installment_12_28' => 'installment_12_28', 
      '_prodamus_checkbox_installment_0_0_3' => 'installment_0_0_3', 
      '_prodamus_checkbox_installment_0_0_4' => 'installment_0_0_4', 
      '_prodamus_checkbox_installment_0_0_6' => 'installment_0_0_6', 
      '_prodamus_checkbox_installment_0_0_10' => 'installment_0_0_10', 
      '_prodamus_checkbox_installment_0_0_12' => 'installment_0_0_12', 
      '_prodamus_checkbox_installment_0_0_24' => 'installment_0_0_24', 
      '_prodamus_checkbox_credit' => 'credit', 
      '_prodamus_checkbox_vsegdada_installment_0_0_4' => 'vsegdada_installment_0_0_4', 
      '_prodamus_checkbox_vsegdada_installment_0_0_6' => 'vsegdada_installment_0_0_6', 
      '_prodamus_checkbox_vsegdada_installment_0_0_10' => 'vsegdada_installment_0_0_10', 
      '_prodamus_checkbox_vsegdada_installment_0_0_12' => 'vsegdada_installment_0_0_12', 
      '_prodamus_checkbox_vsegdada_installment_0_0_24' => 'vsegdada_installment_0_0_24'
    ];    

    public function __construct()
    {
      $this->id = "prodamus";
      $this->has_fields = false;
      $this->method_title = __("Продамус.Платежи", "wc-prodamus");
      $this->method_description = __("Настройка приема электронных платежей через Продамус.Платежи.", "wc-prodamus");
      $this->init_form_fields();
      $this->init_settings();
      $this->title = $this->get_option("title");
      $this->demo_mode = $this->get_option("demo_mode");
      $this->description = $this->get_option("description");
      $this->payment_site_name = $this->get_option("payment_site_name");
      $this->secret_key = $this->get_option("secret_key");
      $this->order_status = $this->get_option("order_status");
      $this->urlReturn = $this->get_option("urlReturn");
      $this->urlSuccess = $this->get_option("urlSuccess");
      $this->order_status_ready_pay = $this->get_option("order_status_ready_pay");
      $this->availableMethods = $this->get_option("availableMethods");
      $this->currency = $this->get_option("currency");
      $icon = $this->get_option("icon");
      if (empty($this->payment_site_name) || empty($this->secret_key)) {
        $this->enabled = "no";
      }

      add_action(
        "woocommerce_update_options_payment_gateways_" . $this->id,
        [$this, "process_admin_options"]
      );
      add_action("woocommerce_receipt_" . $this->id, [
        $this,
        "receipt_page",
      ]);
      add_action("woocommerce_thankyou_" . $this->id, [
        $this,
        "thankyou_page",
      ]);

      add_action("woocommerce_api_" . $this->id, [$this, "api_handler"]);
      add_action("wp_enqueue_scripts", [$this, "enqueue_scripts"]);
    }

    function init_form_fields()
    {
      $this->form_fields = [
        "enabled" => [
          "title" => __(
            "Активность способа оплаты",
            "wc-prodamus"
          ),
          "type" => "checkbox",
          "label" => __("Активен", "wc-prodamus"),
          "default" => "yes",
        ],
        "demo_mode" => [
          "title" => __(
            "Тестовый режим",
            "wc-prodamus"
          ),
          "type" => "checkbox",
          "label" => __("Активен", "wc-prodamus"),
          "default" => "no",
        ],
        "title" => [
          "title" => __(
            "Название способа оплаты",
            "wc-prodamus"
          ),
          "type" => "text",
          "description" => __(
            "Название способа оплаты, которое увидит пользователь при оформлении заказа",
            "wc-prodamus"
          ),
          "default" => __(
            "Продамус",
            "wc-prodamus"
          ),
          "placeholder" => __(
            "Продамус.Платежи",
            "wc-prodamus"
          ),
        ],
        "description" => [
          "title" => __(
            "Описание способа оплаты",
            "wc-prodamus"
          ),
          "type" => "textarea",
          "description" => __(
            "Описание способа оплаты, которое клиент будет видеть на вашем сайте.",
            "wc-prodamus"
          ),
          "placeholder" => __(
            "Описание способа оплаты, которое клиент будет видеть на вашем сайте.",
            "wc-prodamus"
          ),
        ],
        "payment_site_name" => [
          "title" => __(
            "Адрес платежной страницы",
            "wc-prodamus"
          ),
          "type" => "text",
          "description" => __(
            "Адрес Вашей платежной страницы в Продамус.Платежи",
            "wc-prodamus"
          ),
          "default" => "",
          "placeholder" => "https:/pay.domain.net/",
        ],
        "secret_key" => [
          "title" => __(
            "Секретный ключ",
            "wc-prodamus"
          ),
          "type" => "text",
          "description" => __(
            "Необходимо получить в личном кабинете Промадус",
            "wc-prodamus"
          ),
          "default" => "",
        ],
        "order_status" => [
          "title" => __(
            "Статус заказа",
            "wc-prodamus"
          ),
          "type" => "select",
          "class" => "wc-enhanced-select",
          "description" => __(
            "Статус заказа, который будет установлен после успешной оплаты.",
            "wc-prodamus"
          ),
          "default" => "processing",
          "options" => [
            "pending" => __(
              "Ожидается оплата",
              "wc-prodamus"
            ),
            "on-hold" => __(
              "На удержании",
              "wc-prodamus"
            ),
            "cancelled" => __(
              "Отменен",
              "wc-prodamus"
            ),
            "failed" => __(
              "Не удался",
              "wc-prodamus"
            ),
            "refunded" => __(
              "Возвращен",
              "wc-prodamus"
            ),
            "draft" => __(
              "Черновик",
              "wc-prodamus"
            ),
            "processing" => __(
              "В обработке",
              "wc-prodamus"
            ),
            "completed" => __(
              "Выполнен",
              "wc-prodamus"
            ),
          ],
        ],
        "order_status_ready_pay" => [
          "title" => __(
            "Статус заказа из которого можно переходить к оплате",
            "wc-prodamus"
          ),
          "type" => "select",
          "class" => "wc-enhanced-select",
          "description" => __(
            "Статус заказа из которого можно переходить к оплате",
            "wc-prodamus"
          ),
          "default" => "processing",
          "options" => [
            "pending" => __(
              "Ожидается оплата",
              "wc-prodamus"
            ),
            "on-hold" => __(
              "На удержании",
              "wc-prodamus"
            ),
            "cancelled" => __(
              "Отменен",
              "wc-prodamus"
            ),
            "failed" => __(
              "Не удался",
              "wc-prodamus"
            ),
            "refunded" => __(
              "Возвращен",
              "wc-prodamus"
            ),
            "draft" => __(
              "Черновик",
              "wc-prodamus"
            ),
            "processing" => __(
              "В обработке",
              "wc-prodamus"
            ),
            "completed" => __(
              "Выполнен",
              "wc-prodamus"
            ),
          ],
        ],
        "urlReturn" => [
          "title" => __(
            "URL-адрес для возврата пользователя без оплаты",
            "wc-prodamus"
          ),
          "type" => "text",
          "description" => __("", "wc-prodamus"),
          "default" => esc_url_raw(wc_get_checkout_url()),
        ],
        "urlSuccess" => [
          "title" => __(
            "URL-адрес для возврата пользователя при успешной оплате",
            "wc-prodamus"
          ),
          "type" => "text",
          "default" => esc_url_raw(wc_get_checkout_url()),
        ],
        "availableMethods" => [
          "title" => __(
            "Доступные методы оплаты",
            "wc-prodamus"
          ),
          "type" => "text",
          "description" => __(
            "Список доступных методов оплаты. Разделять вертикальной чертой #Пример: AC|sbol",
            "wc-prodamus"
          ),
          "default" => "",
        ],
        "currency" => [
          "title" => __(
            "Используемая валюта",
            "wc-prodamus"
          ),
          "type" => "select",
          "class" => "wc-enhanced-select",
          "description" => __(
            "Валюта заказа, которая будет оправляться в платежную систему.",
            "wc-prodamus"
          ),
          "default" => "processing",
          "options" => [
            "rub" => __(
              "rub",
              "wc-prodamus"
            ),
            "byn" => __(
              "byn",
              "wc-prodamus"
            ),            
            "usd" => __(
              "usd",
              "wc-prodamus"
            ),
            "eur" => __(
              "eur",
              "wc-prodamus"
            ),
            "kzt" => __(
              "kzt",
              "wc-prodamus"
            ),
          ],
        ],
      ];
    }

    public function admin_options()
    {
      if (empty($this->payment_site_name) || empty($this->secret_key)) {
        echo '<div class="error notice">';
        echo "<p>";
        _e(
          'Не завершена настройка метода оплаты. Проверьте заполнены ли настройки "Адрес платежной страницы" и "Секретный ключ".',
          "wc-prodamus"
        );
        echo "</p>";
        echo "</div>";
      }
      parent::admin_options();
    }

    public function process_payment($order_id)
    {
      if (empty($this->payment_site_name) || empty($this->secret_key)) {
        wc_add_notice(
          __(
            "Не завершена настройка метода оплаты",
            "wc-prodamus"
          ),
          "error"
        );
        return;
      }
      
      global $woocommerce;
      
      $order = wc_get_order($order_id);
      $params = [];
      $params["order_id"] = $order->get_order_number();
      $params["products"] = [];
      $params["customer_phone"] = $order->billing_phone;
      $params["customer_email"] = $order->billing_email;
      if ($this->demo_mode !== "no") {
        $params["demo_mode"] = 1;
      }
      $params["npd_income_type"] = 'FROM_INDIVIDUAL';
      $params["currency"] = $this->currency;
      $params["do"] = "pay";
      $params["sys"] = "wordpress2";
      $params["urlReturn"] = $this->urlReturn;
      $params["urlSuccess"] = $this->urlSuccess;
      $params["urlNotification"] = get_site_url() . "/wc-api/prodamus/?order_id=" . $order->get_order_number();
      $params["urlCancel"] = esc_url_raw( $order->get_cancel_order_url_raw() );

      $avail_methods = [];
      $astable_flag = [];
      foreach ($order->get_items() as $item_key => $item_values) {
        $product_id = $item_values->get_product_id(); 
 
        // Методы оплаты, выбранные в товарах
        foreach($this->prodamus_payment_methods as $method_field => $method_name){
          if(get_post_meta($product_id, $method_field)[0] !== "no"){
            $avail_methods[$method_name] = $method_name;
          }
        }

        $astable_flag[] = (get_post_meta($product_id, '_prodamus_checkbox_installments_disabled')[0] !== "no") ? 1 : 0;
      }

      $astable_flag = array_unique($astable_flag);

      if (count($astable_flag) > 1) {
        $params["installments_disabled"] = 1;
      } else {
        if ($astable_flag[0] == 1) {
          $params["installments_disabled"] = 1;
        } else {
          $params["installments_disabled"] = 0;
        }
      }

      $available_payment_methods_config = explode("|", $this->availableMethods);
      $avail_methods = array_intersect($avail_methods, $available_payment_methods_config);
      $available_payment_methods = implode('|', $avail_methods);

      $params["available_payment_methods"] = $available_payment_methods;
      if (empty($available_payment_methods)) {
        $params["available_payment_methods"] = $this->availableMethods;
      }

      if (strlen($params["available_payment_methods"]) == 1) {
        unset($params["available_payment_methods"]);
      }

      $calculated_total = 0;
      foreach ($order->get_items(["line_item", "fee"]) as $item) {
        $product_id = $item->get_product_id();

        if ("fee" === $item["type"]) {
          $item_line_total = sprintf("%.2f", $item["line_total"]);
          $calculated_total += $item_line_total;
          $product = [
            "sku" => $product_id,
            "name" => $item["name"],
            "price" => $item_line_total,
            "quantity" => 1,
          ];
        } else {
          $item_line_total = sprintf(
            "%.2f",
            $order->get_item_total($item, false)
          );
          $calculated_total += $item_line_total * $item["qty"];
          $product = [
            "sku" => $product_id,
            "name" => $item["name"],
            "price" => $item_line_total,
            "quantity" => $item["qty"],
          ];
          $product["name"] = $item["name"];
          $item_meta = new WC_Order_Item_Meta($item);

          if ($meta = $item_meta->display(true, true)) {
            $product["name"] .= " ( " . $meta . " )";
          }
        }

        $params["discount_value"] = 0.00;
        $params["products"][] = $product;
      }

      if ($order->get_shipping_methods()) {
        $item_line_total = sprintf(
          "%.2f",
          method_exists($order, "get_shipping_total")
          ? $order->get_shipping_total()
          : $order->get_total_shipping()
        );
        $params["products"][] = [
          "sku" => 'delivery',
          "name" => sprintf(
            "Доставка: %s",
            $order->get_shipping_method()
          ),
          "price" => $item_line_total,
          "quantity" => 1,
        ];
        $calculated_total += $item_line_total;
      }
      
      if (strtolower(get_bloginfo("charset")) != strtolower("utf-8")) {
        array_walk_recursive($params, function (&$v) {
          $v = iconv(get_bloginfo("charset"), "utf-8//TRANSLIT", $v);
        });
      }
      
      $params["signature"] = $this->_createHmac($params);

      if ($order->get_status() == $this->order_status_ready_pay) {
        $woocommerce->cart->empty_cart();
        
        return [
          "result" => "success",
          "redirect" =>
            $this->payment_site_name .
            (strpos($this->payment_site_name, "?") === false
              ? "?"
              : "&") .
            http_build_query($params, "", "&"),
        ];
      } else {
        wc_add_notice(
          __("Ваш заказ не подтвержден менеджером", "wc-prodamus"),
          "error"
        );
      }
    }

    function receipt_page($order_id)
    {
      wc_add_notice(
        __(
          "Вы попали на эту страницу по ошибке",
          "wc-prodamus"
        ),
        "error"
      );
    }

    function thankyou_page($order_id)
    {
      $order = wc_get_order($order_id);
      $data = empty($_POST) ? $_GET : $_POST;
      $payform_data = [];           

      array_walk($data, function (&$v, $k) use (&$payform_data) {
        if (preg_match('~^_payform_(.*)$~', $k, $m)) {
          $payform_data[$k] = $v;
        }
      });

      $payform_data_sign = isset($payform_data["_payform_sign"]) ? $payform_data["_payform_sign"] : "";

      unset($payform_data["_payform_sign"]);

      if (!empty($payform_data)) {
        try {
        
          if (empty($payform_data_sign)) {
            throw new Exception("Платеж выполнен успешно");
          }
          
          if (
            empty($this->payment_site_name) ||
            empty($this->secret_key)
          ) {
            throw new Exception( "Не завершена настройка метода оплаты" );
          }
          
          if (
            !$this->_verifyHmac($payform_data, $payform_data_sign)
          ) {
            throw new Exception( "Ошибка подписи передаваемых данных" );
          }
          
          if (
            isset($payform_data["_payform_order_id"]) &&
            $payform_data["_payform_order_id"] !=
            $order->get_order_number()
          ) {
            throw new Exception( "Ошибка передаваемых данных. Не совпадает ID заказа" );
          }
          
          if (!isset($payform_data["_payform_status"])) {
            throw new Exception( "Ошибка передаваемых данных. Не указан результат оплаты." );
          }
          
          if (
            !in_array($payform_data["_payform_status"], ["success"])
          ) {
            throw new Exception( "Ошибка передаваемых данных. Неизвестный результат оплаты." );
          }
          
          if ("success" == $payform_data["_payform_status"]) {
            $order->update_status(
              $this->order_status,
              __( "Платеж выполнен успешно", "wc-prodamus" )
            );
            $order->payment_complete();
            $order->reduce_order_stock();
            
            echo "<h1>Благодарим вас за покупку!</h1>";
            echo '<div class="woocommerce-message">Платеж успешно совершен.</div>';
          }
        } catch (Exception $e) {
          wc_add_notice(
            __($e->getMessage(), "wc-prodamus"),
            "error"
          );
        }
      }
    }

    function api_handler()
    {        

      $headers = getallheaders();
      $payform_data = $_POST;
      $payform_data_sign = isset($headers["Sign"]) ? $headers["Sign"] : "";

      if ( !empty($payform_data["payment_status"]) && $payform_data["payment_status"] == "success" ) {
        try {
          if (empty($payform_data_sign)) {
            throw new Exception("Отсутствует подпись запроса");
          }
          
          if (
            empty($this->payment_site_name) ||
            empty($this->secret_key)
          ) {
            throw new Exception( "Не завершена настройка метода оплаты" );
          }
          
          if (
            !$this->_verifyHmac($payform_data, $payform_data_sign)
          ) {
            throw new Exception( "Ошибка подписи передаваемых данных" );
          }
          
          if (
            empty($payform_data["order_num"]) ||
            empty($_GET["order_id"])
          ) {
            throw new Exception("Отсутствует номер заказа");
          }
          
          if ($payform_data["order_num"] != $_GET["order_id"]) {
            throw new Exception( "Ошибка передаваемых данных. Не совпадает ID заказа" );
          }
          
          $order_id = $payform_data["order_num"];
          $order = wc_get_order($order_id);
          
          if (!$order) {
            throw new Exception("Заказ не найден");
          }
          
          $order->update_status(
            $this->order_status,
            __( "Платеж выполнен успешно", "wc-prodamus" )
          );
          $order->payment_complete();
          $order->reduce_order_stock();

          die("success");
        } catch (Exception $e) {
          die($e->getMessage());
        }
      }
      die(
        __( "Вы попали на эту страницу по ошибке", "wc-prodamus" )
      );
    }

    function enqueue_scripts()
    {
      wp_register_style(
        "woocommerce-gateway-prodamus",
        plugin_dir_url(__FILE__) . "assets/css/style.css"
      );
      wp_enqueue_style("woocommerce-gateway-prodamus");
    }

    private function _createHmac($data)
    {
      $data = (array) $data;
      array_walk_recursive($data, function (&$v) {
        $v = strval($v);
      });
      $this->_sort($data);
      if (version_compare(PHP_VERSION, "5.4.0", "<")) {
        $data = preg_replace_callback(
          "/((\\\u[01-9a-fA-F]{4})+)/",
          function ($matches) {
            return json_decode('"' . $matches[1] . '"');
          },
          json_encode($data)
        );
      } else {
        $data = json_encode($data, JSON_UNESCAPED_UNICODE);
      }
      return hash_hmac("sha256", $data, $this->secret_key);
    }

    private function _verifyHmac($data, $sign)
    {
      $_sign = $this->_createHmac($data);
      return $_sign && strtolower($_sign) == strtolower($sign);
    }

    private function _sort(&$data)
    {
      ksort($data, SORT_REGULAR);
      foreach ($data as &$arr) {
        is_array($arr) && $this->_sort($arr);
      }
    }
  }
}

add_action('plugins_loaded', function () {
  $mo_file_path = dirname(__FILE__) . '/wc-prodamus-' . get_locale() . '.mo';
  load_textdomain('wc-prodamus', $mo_file_path);
});

add_action('woocommerce_product_options_general_product_data', 'art_woo_add_custom_fields');
function art_woo_add_custom_fields()
{
  global $product, $post;
  echo '<div class="options_group">';// Группировка полей
  echo '<div class="prodamus-cols">';
  echo '<div class="prodamus-item">';
  woocommerce_wp_checkbox(array(
    'id' => '_prodamus_checkbox_installments_disabled',
    'label' => 'Рассрочки/кредиты отключены',
    'description' => '',
  ));
  woocommerce_wp_checkbox(array(
    'id' => '_prodamus_checkbox_AC',
    'label' => 'Оплата картой, выпущенной в РФ	Обычный платеж',
    'description' => '',
  ));
  woocommerce_wp_checkbox(array(
    'id' => '_prodamus_checkbox_SBP',
    'label' => 'Быстрый платёж, без ввода данных карты. Для карт РФ	Обычный платеж',
    'description' => '',
  ));
  woocommerce_wp_checkbox(array(
    'id' => '_prodamus_checkbox_ACeuruk',
    'label' => 'Оплата в EUR картой всех стран, кроме РФ и РБ	Международный платеж',
    'description' => '',
  ));
  woocommerce_wp_checkbox(array(
    'id' => '_prodamus_checkbox_ACf',
    'label' => 'Оплата картами стран СНГ, кроме РФ	Международный платеж',
    'description' => '',
  ));
  woocommerce_wp_checkbox(array(
    'id' => '_prodamus_checkbox_ACkz',
    'label' => 'Оплата картой Казахстана	Международный платеж',
    'description' => '',
  ));
  woocommerce_wp_checkbox(array(
    'id' => '_prodamus_checkbox_ACkztjp',
    'label' => 'Оплата картой всех стран мира, кроме РФ	Международный платеж',
    'description' => '',
  ));
  echo "</div>";
  
  echo '<div class="prodamus-item">';
  woocommerce_wp_checkbox(array(
    'id' => '_prodamus_checkbox_ACBYNGTL',
    'label' => 'GateLine в бел. руб.',
    'description' => '',
  ));
  woocommerce_wp_checkbox(array(
    'id' => '_prodamus_checkbox_PC',
    'label' => 'Юmoney	Обычный платеж',
    'description' => '',
  ));
  woocommerce_wp_checkbox(array(
    'id' => '_prodamus_checkbox_QW',
    'label' => 'Qiwi Wallet	Обычный платеж',
    'description' => '',
  ));
  woocommerce_wp_checkbox(array(
    'id' => '_prodamus_checkbox_GP',
    'label' => 'Платежный терминал	Обычный платеж',
    'description' => '',
  ));
  woocommerce_wp_checkbox(array(
    'id' => '_prodamus_checkbox_sbol',
    'label' => 'Сбербанк онлайн	Обычный платеж',
    'description' => '',
  ));
  woocommerce_wp_checkbox(array(
    'id' => '_prodamus_checkbox_invoice',
    'label' => 'Оплата по счету	Обычный платеж',
    'description' => '',
  ));
  woocommerce_wp_checkbox(array(
    'id' => '_prodamus_checkbox_installment',
    'label' => 'Частями от Продамус',
    'description' => '',
  ));
  echo "</div>";
  
  echo '<div class="prodamus-item">';
  woocommerce_wp_checkbox(array(
    'id' => '_prodamus_checkbox_installment_5_21',
    'label' => 'Частями от Продамус на 3 месяца	Рассрочки-кредиты',
    'description' => '',
  ));
  woocommerce_wp_checkbox(array(
    'id' => '_prodamus_checkbox_installment_6_28',
    'label' => 'Частями от Продамус на 6 месяцев Рассрочки-кредиты',
    'description' => '',
  ));
  woocommerce_wp_checkbox(array(
    'id' => '_prodamus_checkbox_installment_10_28',
    'label' => 'Частями от Продамус на 10 месяцев Рассрочки-кредиты',
    'description' => '',
  ));
  woocommerce_wp_checkbox(array(
    'id' => '_prodamus_checkbox_installment_12_28',
    'label' => 'Частями от Продамус на 12 месяцев Рассрочки-кредиты',
    'description' => '',
  ));
  woocommerce_wp_checkbox(array(
    'id' => '_prodamus_checkbox_installment_0_0_3',
    'label' => 'Рассрочка от Тинькофф на 3 месяца',
    'description' => '',
  ));
  woocommerce_wp_checkbox(array(
    'id' => '_prodamus_checkbox_installment_0_0_4',
    'label' => 'Рассрочка от Тинькофф на 4 месяцев',
    'description' => '',
  ));
  woocommerce_wp_checkbox(array(
    'id' => '_prodamus_checkbox_installment_0_0_6',
    'label' => 'Рассрочка от Тинькофф на 6 месяцев',
    'description' => '',
  ));
  woocommerce_wp_checkbox(array(
    'id' => '_prodamus_checkbox_installment_0_0_10',
    'label' => 'Рассрочка от Тинькофф на 10 месяцев',
    'description' => '',
  ));
  woocommerce_wp_checkbox(array(
    'id' => '_prodamus_checkbox_installment_0_0_12',
    'label' => 'Рассрочка от Тинькофф на 12 месяцев',
    'description' => '',
  ));
  echo "</div>";
  echo '<div class="prodamus-item">';
  woocommerce_wp_checkbox(array(
    'id' => '_prodamus_checkbox_installment_0_0_24',
    'label' => 'Рассрочка от Тинькофф на 24 месяца',
    'description' => '',
  ));
  woocommerce_wp_checkbox(array(
    'id' => '_prodamus_checkbox_credit',
    'label' => 'Кредит от Тинькофф',
    'description' => '',
  ));
  woocommerce_wp_checkbox(array(
    'id' => '_prodamus_checkbox_vsegdada_installment_0_0_4',
    'label' => 'Рассрочка Всегда.Да на 4 месяца без переплаты!',
    'description' => '',
  ))
  ;
  woocommerce_wp_checkbox(array(
    'id' => '_prodamus_checkbox_vsegdada_installment_0_0_6',
    'label' => 'Рассрочка от ВсегдаДа на 6 месяцев без переплаты!',
    'description' => '',
  ));
  woocommerce_wp_checkbox(array(
    'id' => '_prodamus_checkbox_vsegdada_installment_0_0_10',
    'label' => 'Рассрочка от ВсегдаДа на 10 месяцев без переплаты!',
    'description' => '',
  ));
  woocommerce_wp_checkbox(array(
    'id' => '_prodamus_checkbox_vsegdada_installment_0_0_12',
    'label' => 'Рассрочка от ВсегдаДа на 12 месяцев без переплаты!',
    'description' => '',
  ));
  woocommerce_wp_checkbox(array(
    'id' => '_prodamus_checkbox_vsegdada_installment_0_0_24',
    'label' => 'Рассрочка от ВсегдаДа на 24 месяцев без переплаты!',
    'description' => '',
  ));
  echo "</div>";
  echo '</div>';
  echo '</div>';
  echo "<style>.prodamus-cols {white-space: nowrap;font-size: 0;overflow-x: scroll;}.prodamus-item {white-space: normal;	display: inline-block;width: 30%;vertical-align: top;margin-right: 5%;font-size: 14px;}.prodamus-cols .prodamus-item:last-child {margin-right: 0 ;}</style>";
}

add_action('woocommerce_process_product_meta', 'art_woo_custom_fields_save', 10);
function art_woo_custom_fields_save($post_id)
{
  $product = wc_get_product($post_id);

  $checkbox_field_credit = isset($_POST['_prodamus_checkbox_AC']) ? 'yes' : 'no';
  $product->update_meta_data('_prodamus_checkbox_AC', $checkbox_field_credit);

  $checkbox_field_credit = isset($_POST['_prodamus_checkbox_installments_disabled']) ? 'yes' : 'no';
  $product->update_meta_data('_prodamus_checkbox_installments_disabled', $checkbox_field_credit);

  $checkbox_field = isset($_POST['_prodamus_checkbox_ACUSDXP']) ? 'yes' : 'no';
  $product->update_meta_data('_prodamus_checkbox_ACUSDXP', $checkbox_field);

  $checkbox_field = isset($_POST['_prodamus_checkbox_ACeuruk']) ? 'yes' : 'no';
  $product->update_meta_data('_prodamus_checkbox_ACeuruk', $checkbox_field);

  $checkbox_field = isset($_POST['_prodamus_checkbox_ACkz']) ? 'yes' : 'no';
  $product->update_meta_data('_prodamus_checkbox_ACkz', $checkbox_field);

  $checkbox_field = isset($_POST['_prodamus_checkbox_ACkztjp']) ? 'yes' : 'no';
  $product->update_meta_data('_prodamus_checkbox_ACkztjp', $checkbox_field);

  $checkbox_field = isset($_POST['_prodamus_checkbox_ACusd']) ? 'yes' : 'no';
  $product->update_meta_data('_prodamus_checkbox_ACusd', $checkbox_field);

  $checkbox_field = isset($_POST['_prodamus_checkbox_installment_5_21']) ? 'yes' : 'no';
  $product->update_meta_data('_prodamus_checkbox_installment_5_21', $checkbox_field);

  $checkbox_field = isset($_POST['_prodamus_checkbox_installment_6_28']) ? 'yes' : 'no';
  $product->update_meta_data('_prodamus_checkbox_installment_6_28', $checkbox_field);

  $checkbox_field = isset($_POST['_prodamus_checkbox_vsegdada_installment_0_0_4']) ? 'yes' : 'no';
  $product->update_meta_data('_prodamus_checkbox_vsegdada_installment_0_0_4', $checkbox_field);

  $checkbox_field = isset($_POST['_prodamus_checkbox_ACf']) ? 'yes' : 'no';
  $product->update_meta_data('_prodamus_checkbox_ACf', $checkbox_field);

  $checkbox_field = isset($_POST['_prodamus_checkbox_installment_10_28']) ? 'yes' : 'no';
  $product->update_meta_data('_prodamus_checkbox_installment_10_28', $checkbox_field);

  $checkbox_field = isset($_POST['_prodamus_checkbox_installment_12_28']) ? 'yes' : 'no';
  $product->update_meta_data('_prodamus_checkbox_installment_12_28', $checkbox_field);

  $checkbox_field = isset($_POST['_prodamus_checkbox_installment_12_38']) ? 'yes' : 'no';
  $product->update_meta_data('_prodamus_checkbox_installment_12_38', $checkbox_field);

  $checkbox_field = isset($_POST['_prodamus_checkbox_ACUSDXP']) ? 'yes' : 'no';
  $product->update_meta_data('_prodamus_checkbox_ACUSDXP', $checkbox_field);

  $checkbox_field = isset($_POST['_prodamus_checkbox_ACeur']) ? 'yes' : 'no';
  $product->update_meta_data('_prodamus_checkbox_ACeur', $checkbox_field);

  $checkbox_field = isset($_POST['_prodamus_checkbox_SBP']) ? 'yes' : 'no';
  $product->update_meta_data('_prodamus_checkbox_SBP', $checkbox_field);

  $checkbox_field = isset($_POST['_prodamus_checkbox_ACBYNGTL']) ? 'yes' : 'no';
  $product->update_meta_data('_prodamus_checkbox_ACBYNGTL', $checkbox_field);

  $checkbox_field = isset($_POST['_prodamus_checkbox_PC']) ? 'yes' : 'no';
  $product->update_meta_data('_prodamus_checkbox_PC', $checkbox_field);

$checkbox_field = isset($_POST['_prodamus_checkbox_QW']) ? 'yes' : 'no';
  $product->update_meta_data('_prodamus_checkbox_QW', $checkbox_field);

  $checkbox_field = isset($_POST['_prodamus_checkbox_GP']) ? 'yes' : 'no';
  $product->update_meta_data('_prodamus_checkbox_GP', $checkbox_field);

  $checkbox_field = isset($_POST['_prodamus_checkbox_sbol']) ? 'yes' : 'no';
  $product->update_meta_data('_prodamus_checkbox_sbol', $checkbox_field);

  $checkbox_field = isset($_POST['_prodamus_checkbox_invoice']) ? 'yes' : 'no';
  $product->update_meta_data('_prodamus_checkbox_invoice', $checkbox_field);

  $checkbox_field = isset($_POST['_prodamus_checkbox_installment']) ? 'yes' : 'no';
  $product->update_meta_data('_prodamus_checkbox_installment', $checkbox_field);

  $checkbox_field = isset($_POST['_prodamus_checkbox_installment_0_0_3']) ? 'yes' : 'no';
  $product->update_meta_data('_prodamus_checkbox_installment_0_0_3', $checkbox_field);

  $checkbox_field = isset($_POST['_prodamus_checkbox_installment_0_0_4']) ? 'yes' : 'no';
  $product->update_meta_data('_prodamus_checkbox_installment_0_0_4', $checkbox_field);

  $checkbox_field = isset($_POST['_prodamus_checkbox_installment_0_0_6']) ? 'yes' : 'no';
  $product->update_meta_data('_prodamus_checkbox_installment_0_0_6', $checkbox_field);

  $checkbox_field = isset($_POST['_prodamus_checkbox_installment_0_0_10']) ? 'yes' : 'no';
  $product->update_meta_data('_prodamus_checkbox_installment_0_0_10', $checkbox_field);

  $checkbox_field = isset($_POST['_prodamus_checkbox_installment_0_0_12']) ? 'yes' : 'no';
  $product->update_meta_data('_prodamus_checkbox_installment_0_0_12', $checkbox_field);

  $checkbox_field = isset($_POST['_prodamus_checkbox_installment_0_0_24']) ? 'yes' : 'no';
  $product->update_meta_data('_prodamus_checkbox_installment_0_0_24', $checkbox_field);

  $checkbox_field = isset($_POST['_prodamus_checkbox_credit']) ? 'yes' : 'no';
  $product->update_meta_data('_prodamus_checkbox_credit', $checkbox_field);

  $checkbox_field = isset($_POST['_prodamus_checkbox_vsegdada_installment_0_0_6']) ? 'yes' : 'no';
  $product->update_meta_data('_prodamus_checkbox_vsegdada_installment_0_0_6', $checkbox_field);

  $checkbox_field = isset($_POST['_prodamus_checkbox_vsegdada_installment_0_0_10']) ? 'yes' : 'no';
  $product->update_meta_data('_prodamus_checkbox_vsegdada_installment_0_0_10', $checkbox_field);

  $checkbox_field = isset($_POST['_prodamus_checkbox_vsegdada_installment_0_0_12']) ? 'yes' : 'no';
  $product->update_meta_data('_prodamus_checkbox_vsegdada_installment_0_0_12', $checkbox_field);

  $checkbox_field = isset($_POST['_prodamus_checkbox_vsegdada_installment_0_0_24']) ? 'yes' : 'no';
  $product->update_meta_data('_prodamus_checkbox_vsegdada_installment_0_0_24', $checkbox_field);

  $product->save();

}

function save_debug_data($file_name, $data, $append = false)
{
  $path = __DIR__;
  $file = $path . '/' . $file_name . '.txt';
  $current = '';

  if (is_file($file) && $append == true) {
    $current = file_get_contents($file);
    $current .= PHP_EOL . PHP_EOL;
  }

  $current .= var_export($data, true);
  file_put_contents($file, $current);
}




<?php
  
use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class wc_prodamus_blocks extends AbstractPaymentMethodType 
{
  
  private $gateway;
  protected $name = 'prodamus';

  public function initialize() 
  {
    $gateways = WC()->payment_gateways->payment_gateways();
    $this->settings = get_option( 'woocommerce_prodamus_settings', [] );            
    $this->gateway = isset($gateways[$this->name]) ? $gateways[$this->name] : '';
  }

  public function is_active() 
  {
    return $this->get_setting( 'enabled' ) === 'yes';
  }

  public function get_payment_method_script_handles() 
  {
    wp_register_script(
      'wc-prodamus-blocks-integration',
      plugin_dir_url(__FILE__) . 'block/checkout.js',
      [
        'wc-blocks-registry',
        'wc-settings',
        'wp-element',
        'wp-html-entities',
        'wp-i18n',
      ],
      false,
      true
    );
    
    if( function_exists( 'wp_set_script_translations' ) ) {
      wp_set_script_translations( 'wc-prodamus-blocks-integration');
    }
    
    return [ 'wc-prodamus-blocks-integration' ];
  }

  public function get_payment_method_data() 
  {
    return [
      'title' => $this->settings['title'],
      'description' => $this->get_setting( 'description' ),
      'supports'    => $this->get_supported_features(),
    ];
  }
}
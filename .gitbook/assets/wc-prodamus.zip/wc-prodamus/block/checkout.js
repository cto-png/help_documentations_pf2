const prodamus_data = window.wc.wcSettings.getSetting( 'prodamus_data', {} );
const prodamus_label = window.wp.htmlEntities.decodeEntities( prodamus_data.title ) || window.wp.i18n.__( 'My Gateway', 'prodamus' );

const Content = () => {
  return React.createElement('div', null,
    React.createElement('p', null, window.wp.htmlEntities.decodeEntities(prodamus_data.description ||  '')),
  );
};

const prodamus = {
    name: 'prodamus',
    label: prodamus_label,
    content: Object( window.wp.element.createElement )( Content, null ),
    edit: Object( window.wp.element.createElement )( Content, null ),
    canMakePayment: () => true,
    ariaLabel: prodamus_label
};
window.wc.wcBlocksRegistry.registerPaymentMethod( prodamus );